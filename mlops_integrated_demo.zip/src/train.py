from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd

import mlflow
from mlflow.models.signature import infer_signature

try:
    import xgboost as xgb
except Exception as e:  # pragma: no cover
    raise RuntimeError("xgboost is required for training. Install requirements.txt") from e

from sklearn.metrics import f1_score
from sklearn.model_selection import GroupKFold


@dataclass
class TrainConfig:
    model_name: str = "sales-quantity-classifier"
    experiment_name: str = "sales-quantity-demo"
    tracking_uri: str | None = None  # e.g., http://localhost:5000
    random_seed: int = 42

    # Feature generation
    lags: Tuple[int, ...] = (1, 2, 3, 7, 14)
    windows: Tuple[int, ...] = (3, 7, 14, 30)

    # CV + thresholding
    n_splits: int = 5
    threshold_grid: Tuple[float, ...] = tuple(np.round(np.linspace(0.05, 0.95, 19), 2))

    # XGBoost params (CPU-friendly defaults)
    params: Dict[str, Any] = None


def _default_xgb_params() -> Dict[str, Any]:
    return dict(
        n_estimators=600,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.9,
        colsample_bytree=0.9,
        reg_lambda=1.0,
        min_child_weight=1.0,
        objective="binary:logistic",
        eval_metric="logloss",
        tree_method="hist",
        random_state=42,
    )


def _ensure_config(cfg: TrainConfig) -> TrainConfig:
    if cfg.params is None:
        cfg.params = _default_xgb_params()
    return cfg


def _make_date(df: pd.DataFrame) -> pd.Series:
    return pd.to_datetime(dict(year=df["year"], month=df["month"], day=df["day"]), errors="coerce")


def add_lag_rolling_features(df: pd.DataFrame, group_col: str = "h_item_branch") -> pd.DataFrame:
    """
    Builds past-only lag & rolling features from QuantitySold.
    IMPORTANT: QuantitySold itself must NOT be used as a model feature.
    """
    out = df.copy()
    out["__date"] = _make_date(out)
    out = out.sort_values([group_col, "__date"]).reset_index(drop=True)

    g = out.groupby(group_col, sort=False)["QuantitySold"]

    for k in (1, 2, 3, 7, 14):
        out[f"qty_lag_{k}"] = g.shift(k)

    for w in (3, 7, 14, 30):
        shifted = g.shift(1)  # past-only window
        out[f"qty_roll_mean_{w}"] = shifted.rolling(w, min_periods=1).mean()
        out[f"qty_roll_std_{w}"] = shifted.rolling(w, min_periods=1).std().fillna(0.0)
        out[f"qty_roll_min_{w}"] = shifted.rolling(w, min_periods=1).min()
        out[f"qty_roll_max_{w}"] = shifted.rolling(w, min_periods=1).max()

    out = out.drop(columns=["__date"])
    return out


def build_features(train_df: pd.DataFrame, test_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, List[str]]:
    """
    Concatenate train+test to compute lags using the full historical timeline,
    then split back (realistic: test can use train history).
    """
    combined = pd.concat(
        [train_df.assign(__split="train"), test_df.assign(__split="test")],
        axis=0,
        ignore_index=True,
    )
    combined = add_lag_rolling_features(combined, group_col="h_item_branch")

    # Fill NaNs from early history
    lag_cols = [c for c in combined.columns if c.startswith("qty_")]
    combined[lag_cols] = combined[lag_cols].fillna(0.0)

    # Feature list: exclude raw QuantitySold and target
    drop_cols = {"QuantitySold", "y_class", "__split"}
    feature_cols = [c for c in combined.columns if c not in drop_cols]

    train_out = combined[combined["__split"] == "train"].drop(columns=["__split"]).reset_index(drop=True)
    test_out = combined[combined["__split"] == "test"].drop(columns=["__split"]).reset_index(drop=True)
    return train_out, test_out, feature_cols


def select_threshold_cv(
    X: pd.DataFrame, y: np.ndarray, groups: np.ndarray, thresholds: List[float], n_splits: int
) -> Tuple[float, float]:
    """Pick threshold that maximizes mean CV F1."""
    gkf = GroupKFold(n_splits=n_splits)
    scores = {t: [] for t in thresholds}

    for tr_idx, va_idx in gkf.split(X, y, groups=groups):
        X_tr, X_va = X.iloc[tr_idx], X.iloc[va_idx]
        y_tr, y_va = y[tr_idx], y[va_idx]

        model = xgb.XGBClassifier(**_default_xgb_params())
        model.fit(X_tr, y_tr)

        proba = model.predict_proba(X_va)[:, 1]
        for t in thresholds:
            pred = (proba >= t).astype(int)
            scores[t].append(f1_score(y_va, pred))

    mean_scores = {t: float(np.mean(v)) for t, v in scores.items()}
    best_t = max(mean_scores, key=mean_scores.get)
    return float(best_t), float(mean_scores[best_t])


def train_model(data_paths: Dict[str, Any], cfg: TrainConfig | None = None) -> str:
    """
    Train low-vs-rest model and log to MLflow.

    Returns:
        model_uri (runs:/.../model)
    """
    cfg = _ensure_config(cfg or TrainConfig())

    if cfg.tracking_uri or os.getenv("MLFLOW_TRACKING_URI"):
        mlflow.set_tracking_uri(cfg.tracking_uri or os.getenv("MLFLOW_TRACKING_URI"))

    mlflow.set_experiment(cfg.experiment_name)

    train_path = data_paths["train_path"]
    test_path = data_paths["test_path"]

    train_df = pd.read_csv(train_path)
    test_df = pd.read_csv(test_path)

    train_fe, test_fe, feature_cols = build_features(train_df, test_df)

    y = (train_fe["y_class"].to_numpy().astype(int) == 0).astype(int)  # LOW vs REST
    groups = train_fe["h_item_branch"].to_numpy().astype(int)

    X = train_fe[feature_cols]
    X_test = test_fe[feature_cols]

    # Threshold selection on TRAIN only
    thresholds = list(cfg.threshold_grid)
    best_t, best_f1 = select_threshold_cv(X, y, groups, thresholds, cfg.n_splits)

    # Final model
    model = xgb.XGBClassifier(**cfg.params)
    model.fit(X, y)

    # Log to MLflow
    with mlflow.start_run(run_name="xgb_low_vs_rest") as run:
        mlflow.log_params({f"xgb_{k}": v for k, v in cfg.params.items()})
        mlflow.log_param("best_threshold", best_t)
        mlflow.log_param("cv_mean_f1", best_f1)
        mlflow.log_param("feature_count", len(feature_cols))

        # Metrics on train (for demo; evaluation step will do proper test metrics)
        train_proba = model.predict_proba(X)[:, 1]
        train_pred = (train_proba >= best_t).astype(int)
        mlflow.log_metric("train_f1", float(f1_score(y, train_pred)))

        # Save model artifact (MLflow)
        signature = infer_signature(X.head(20), model.predict_proba(X.head(20)))
        mlflow.xgboost.log_model(model, artifact_path="model", signature=signature)

        # Save config artifact
        model_config = {
            "model_name": cfg.model_name,
            "threshold": best_t,
            "feature_cols": feature_cols,
            "group_col": "h_item_branch",
            "target": "low_vs_rest",
        }
        cfg_path = "model_config.json"
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(model_config, f, indent=2)
        mlflow.log_artifact(cfg_path)

        model_uri = f"runs:/{run.info.run_id}/model"

    return model_uri
